import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my-app';
  months=["jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"];
  isavailable=true;
  /*loc:string;
  course:any[]
  emp={"fname":"priya"};
  constructor(){
    this.loc="Vja"
    this.course=["java","oracle","spring"]
  }
  ngOnInit(){

  }*/
}
