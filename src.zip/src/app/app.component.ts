import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'priya';
  loc:string;
  course:any[]
  emp={"fname":"Pri","lname":"D","age":"22"}
  constructor(){
    this.loc="Vja"
    this.course=["java","oracle"]
  }
  ngOnInit(){
    
  }
}
