import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MydateService {

  constructor() { }
  getDateService():any{
    return new Date();
  }
}
