import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmpService {
  emp=[
    {id:101,fname:"priya"},
    {id:102,fname:"gowtham"},
    {id:103,fname:"kalyan"},
    {id:104,fname:"pavan"},
  ]

  constructor() { }
}
