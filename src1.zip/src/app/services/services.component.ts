import { Component, OnInit } from '@angular/core';
import {MydateService} from '../services/mydate.service';
import {EmpService} from '../services/emp.service';
@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.css']
 // providers:[MydateService]
})
export class ServicesComponent implements OnInit {
today:Date;
  employee: any;
  constructor(private m:MydateService,e:EmpService) { }
  show()
  {
    this.getDate();
  }
  getDate()
  {
    this.today=this.m.getDateService();
    this.employee=this.employee.getEmpService();
  }
  ngOnInit(): void {
  }

}
