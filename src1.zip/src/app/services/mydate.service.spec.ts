import { TestBed } from '@angular/core/testing';

import { MydateService } from './mydate.service';

describe('MydateService', () => {
  let service: MydateService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MydateService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
