import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipedemo',
  templateUrl: './pipedemo.component.html',
  styleUrls: ['./pipedemo.component.css']
})
export class PipedemoComponent implements OnInit {
  rows=3;
  emp=[
    {id:101,fname:"priya",loc:"vja",sal:5673.738,date:new Date(),gender:1},
    {id:102,fname:"riya",loc:"pune",sal:2673.738,date:new Date(),gender:1},
    {id:103,fname:"teja",loc:"wg",sal:3673.738,date:new Date(),gender:2},
    {id:104,fname:"pavan",loc:"hyd",sal:4673.738,date:new Date(),gender:2},
    {id:105,fname:"xyz",loc:"india",sal:1673.738,date:new Date(),gender:3}
  ]
  constructor() { }
  ngOnInit(): void {
  }
}
