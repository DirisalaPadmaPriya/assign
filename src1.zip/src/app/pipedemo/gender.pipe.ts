import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'gender'
})
export class GenderPipe implements PipeTransform {

  transform(value: any): any{
    switch(value){
    case 1:return "miss";
    case 2:return "mr";
    case 3:return "notdisclosed"
    }
  }

}
