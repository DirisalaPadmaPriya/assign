import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servicedemo',
  templateUrl: './servicedemo.component.html',
  styleUrls: ['./servicedemo.component.css']
})
export class ServicedemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
