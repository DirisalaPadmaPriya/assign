import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PipedemoComponent } from './pipedemo/pipedemo.component';
import { GenderPipe } from './pipedemo/gender.pipe';
import { ServicesComponent } from './services/services.component';
import { ServicedemoComponent } from './servicedemo/servicedemo.component';

@NgModule({
  declarations: [
    AppComponent,
    PipedemoComponent,
    GenderPipe,
    ServicesComponent,
    ServicedemoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
